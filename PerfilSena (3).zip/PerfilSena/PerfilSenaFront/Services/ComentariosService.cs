﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Components.Forms;
using PerfilSenaFront.Models;

namespace PerfilSenaFront.Services
{
    public class ComentariosService
    {
        private readonly HttpClient _http;

        public ComentariosService(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<Comentarios>> ObtenerComentarios(int perfilId)
        {
            return await _http.GetFromJsonAsync<List<Comentarios>>($"api/Comentarios/{perfilId}") ?? new List<Comentarios>();
        }

        public async Task CrearComentario(int perfilId, string texto, IBrowserFile? archivo)
        {
            var content = new MultipartFormDataContent();
            content.Add(new StringContent(perfilId.ToString()), "PerfilId");
            content.Add(new StringContent(texto), "TextoComentario");

            if (archivo != null)
            {
                var stream = archivo.OpenReadStream(maxAllowedSize: 10_485_760); // 10 MB
                var fileContent = new StreamContent(stream);
                fileContent.Headers.ContentType = new MediaTypeHeaderValue(archivo.ContentType);
                content.Add(fileContent, "Archivo", archivo.Name);
            }

            var response = await _http.PostAsync("api/Comentarios", content);
            response.EnsureSuccessStatusCode();
        }

        public async Task EliminarComentario(int id)
        {
            var response = await _http.DeleteAsync($"api/Comentarios/{id}");
            response.EnsureSuccessStatusCode();
        }
    }
}
