﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Components.Forms;
using PerfilSenaFront.Models;

namespace PerfilSenaFront.Services
{
    public class CamiloVergaraService
    {
        private readonly HttpClient _http;

        public CamiloVergaraService(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<CamiloVergara>> ObtenerPerfiles()
        {
            return await _http.GetFromJsonAsync<List<CamiloVergara>>("api/CamiloVergara") ?? new List<CamiloVergara>();
        }

        public async Task<CamiloVergara> CrearPerfil(string nombre, string descripcion, IBrowserFile imagen)
        {
            var content = new MultipartFormDataContent();
            content.Add(new StringContent(nombre), "Nombre");
            content.Add(new StringContent(descripcion), "Descripcion");

            var stream = imagen.OpenReadStream(maxAllowedSize: 10_485_760); // 10 MB
            var fileContent = new StreamContent(stream);
            fileContent.Headers.ContentType = new MediaTypeHeaderValue(imagen.ContentType);
            content.Add(fileContent, "imagen", imagen.Name);

            var response = await _http.PostAsync("api/CamiloVergara", content);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<CamiloVergara>()!;
        }

        public async Task EliminarPerfil(int id)
        {
            var response = await _http.DeleteAsync($"api/CamiloVergara/{id}");
            response.EnsureSuccessStatusCode();
        }
    }
}
