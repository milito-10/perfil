﻿using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using PerfilSenaFront;
using PerfilSenaFront.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// HttpClient GLOBAL apuntando al backend
builder.Services.AddScoped(sp =>
    new HttpClient
    {
        BaseAddress = new Uri("http://localhost:5000/") // TU BACKEND
    }
);

// Servicios
builder.Services.AddScoped<CamiloVergaraService>();
builder.Services.AddScoped<ComentariosService>();

await builder.Build().RunAsync();
