﻿namespace PerfilSenaFront.Models
{
    public class Comentarios
    {
        public int Id { get; set; }
        public string TextoComentario { get; set; } = string.Empty;
        public string? RutaArchivo { get; set; }
        public DateTime Fecha { get; set; } = DateTime.Now;
        public int PerfilId { get; set; }
    }
}
