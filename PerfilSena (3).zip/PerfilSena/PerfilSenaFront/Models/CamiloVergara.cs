﻿using System.Collections.Generic;

public class CamiloVergara
{
    public int Id { get; set; }
    public string? Nombre { get; set; }
    public string? Descripcion { get; set; }
    public string? FotoUrl { get; set; }  // Esta es la que usas en <img src="@p.FotoUrl"/>
}
