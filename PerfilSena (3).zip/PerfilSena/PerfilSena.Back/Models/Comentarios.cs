﻿namespace PerfilSena.Back.Models
{
    public class Comentarios
    {
        public int Id { get; set; }

        // Texto del comentario
        public string TextoComentario { get; set; } = string.Empty;

        // Ruta del archivo adjunto (opcional)
        public string? RutaArchivo { get; set; }

        // Fecha y hora en que se creó el comentario
        public DateTime Fecha { get; set; } = DateTime.Now;

        // Id del perfil al que pertenece este comentario
        public int PerfilId { get; set; }

        // Relación con el perfil (opcional)
        public CamiloVergara? Perfil { get; set; }
    }
}