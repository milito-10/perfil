﻿using Microsoft.AspNetCore.Mvc;
using PerfilSena.Back.Models;

namespace PerfilSena.Back.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComentariosController : ControllerBase
    {
        private static List<Comentarios> _comentarios = new();

        // GET: api/Comentarios/{perfilId}
        [HttpGet("{perfilId}")]
        public IActionResult GetComentarios(int perfilId)
        {
            var lista = _comentarios.Where(c => c.PerfilId == perfilId).ToList();
            return Ok(lista);
        }

        // POST: api/Comentarios
        [HttpPost]
        public async Task<IActionResult> CrearComentario([FromForm] int PerfilId, [FromForm] string TextoComentario, IFormFile? Archivo)
        {
            string rutaArchivo = "";
            if (Archivo != null)
            {
                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(Archivo.FileName)}";
                var path = Path.Combine("wwwroot/archivos", fileName);

                using var stream = new FileStream(path, FileMode.Create);
                await Archivo.CopyToAsync(stream);

                rutaArchivo = $"http://localhost:5000/archivos/{fileName}";
            }

            var comentario = new Comentarios
            {
                Id = _comentarios.Count > 0 ? _comentarios.Max(c => c.Id) + 1 : 1,
                PerfilId = PerfilId,
                TextoComentario = TextoComentario,
                RutaArchivo = rutaArchivo
            };

            _comentarios.Add(comentario);

            return Ok(comentario);
        }

        // DELETE: api/Comentarios/{id}
        [HttpDelete("{id}")]
        public IActionResult EliminarComentario(int id)
        {
            var comentario = _comentarios.FirstOrDefault(c => c.Id == id);
            if (comentario == null) return NotFound();

            _comentarios.Remove(comentario);
            return NoContent();
        }
    }
}
