﻿using Microsoft.AspNetCore.Mvc;
using PerfilSena.Back.Models;

namespace PerfilSena.Back.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CamiloVergaraController : ControllerBase
    {
        private static List<CamiloVergara> _perfiles = new();

        // GET: api/CamiloVergara
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_perfiles);
        }

        // POST: api/CamiloVergara
        [HttpPost]
        public async Task<IActionResult> Create([FromForm] CamiloVergara perfil, IFormFile? imagen)
        {
            if (imagen != null)
            {
                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(imagen.FileName)}";
                var path = Path.Combine("wwwroot/imagenes", fileName);

                using var stream = new FileStream(path, FileMode.Create);
                await imagen.CopyToAsync(stream);

                perfil.FotoUrl = $"http://localhost:5000/imagenes/{fileName}";
            }
            else
            {
                perfil.FotoUrl = "https://via.placeholder.com/150";
            }

            perfil.Id = _perfiles.Count > 0 ? _perfiles.Max(p => p.Id) + 1 : 1;
            _perfiles.Add(perfil);

            return Ok(perfil);
        }

        // DELETE: api/CamiloVergara/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var perfil = _perfiles.FirstOrDefault(p => p.Id == id);
            if (perfil == null) return NotFound();

            _perfiles.Remove(perfil);
            return NoContent();
        }
    }
}
