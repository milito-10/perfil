﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PerfilSena.Back.Migrations
{
    /// <inheritdoc />
    public partial class tablaPerfil : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Comentarios_CamiloVergaras_IdPerfil",
                table: "Comentarios");

            migrationBuilder.DropIndex(
                name: "IX_Comentarios_IdPerfil",
                table: "Comentarios");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CamiloVergaras",
                table: "CamiloVergaras");

            migrationBuilder.RenameTable(
                name: "CamiloVergaras",
                newName: "CamiloVergara");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CamiloVergara",
                table: "CamiloVergara",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_CamiloVergara",
                table: "CamiloVergara");

            migrationBuilder.RenameTable(
                name: "CamiloVergara",
                newName: "CamiloVergaras");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CamiloVergaras",
                table: "CamiloVergaras",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_Comentarios_IdPerfil",
                table: "Comentarios",
                column: "IdPerfil");

            migrationBuilder.AddForeignKey(
                name: "FK_Comentarios_CamiloVergaras_IdPerfil",
                table: "Comentarios",
                column: "IdPerfil",
                principalTable: "CamiloVergaras",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
