﻿using Microsoft.EntityFrameworkCore;
using PerfilSena.Back.Models;

namespace PerfilSena.Back.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Comentarios> Comentarios { get; set; }
        public DbSet<CamiloVergara> CamiloVergara { get; set; }
    }
}
